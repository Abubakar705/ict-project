#include<stdio.h>
int search(int arr,int n,int index){
if (index ==0){
    return;
}



}